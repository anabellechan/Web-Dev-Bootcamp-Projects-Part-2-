
import sys

import csv
ic_list=[]
policy_list=[]
agent_list=[]

f=open("CM master.csv", "r") 
with f: 
    reader=csv.DictReader(f)
    for row in reader:
        ic_list.append(row['IC'])
        policy_list.append(row['Policy Number'])
        agent_list.append(row['Agent Code'])

data_dic={}
with open("CM master.csv","r") as ff:
    ffreader=csv.reader(ff)
    header = []
    header = next(ffreader)
    rows = []
    for row in ffreader:
        rows.append(row)
        
for i in range(len(rows)):
    policy = rows[i][4]
    data_dic[policy]=rows[i]
    
def menu():
    print("Welcome to ABC Insurance Claims System")
    print("Please identify yourself.")        
    print("""1) Claimant 
2) Claims Manager 
3) Exit""")
    
def c_final_amount():     #print a new dictionary with updated data, more for checking deductible components
    f=open("CM master.csv", "r+") 
    with f: 
        reader=csv.DictReader(f)

        choice_1=input("Enter the policy number of the client you wish to manage, or input 'Quit' to exit: ")             # choice_1 = policy number
        if choice_1.lower()=="quit":
            print("Have a nice day! Goodbye!")
            sys.exit()
        while not choice_1 in policy_list: 
            choice_1=input("Invalid input! Enter the appropriate policy number of the client you wish to manage, or input 'Quit' to exit: ")
            if choice_1.lower()=="quit":
                print("Have a nice day! Goodbye!")
                sys.exit()
                
                                         
        for row in reader:
            if choice_1==row['Policy Number']: 
                if row['Status']=="New Claim" or row["Status"]=="Pending":
                    choice_2=input("Enter insured amount, or input 'Quit' to exit: ")              # choice_2 = insured amount
                    if choice_2.lower()=="quit":
                        print("Have a nice day! Goodbye!")
                        sys.exit()
                    while choice_2.isnumeric()==False:
                        choice_2=input("Invalid amount! Enter insured amount, or input 'Quit' to exit: ")
                        if choice_2.lower()=="quit":
                            print("Have a nice day! Goodbye!")
                            sys.exit()
                    insured_amount=float(choice_2)
                    row["Insured Amount"]=insured_amount
                        
                        
                    choice_3=input("Enter claim amount, or input 'Quit' to exit: ")              # choice_3 = claim amount
                    if choice_3.lower()=="quit":
                        print("Have a nice day! Goodbye!")
                        sys.exit()
                    while choice_3.isnumeric()==False:
                        choice_3=input("Invalid amount! Enter claim amount, or input 'Quit' to exit: ")
                        if choice_3.lower()=="quit":
                            print("Have a nice day! Goodbye!")
                            sys.exit()
                    while float(choice_3)>float(choice_2):
                        choice_3=input("Claim amount cannot be larger than insured amount! Enter claim amount, or input 'Quit' to exit':")
                        if choice_3.lower()=="quit":
                            print("Have a nice day! Goodbye!")
                            sys.exit()
                        while choice_3.isnumeric()==False:
                            choice_3=input("Invalid amount! Enter claim amount, or input 'Quit' to exit: ")
                            if choice_3.lower()=="quit":
                                print("Have a nice day! Goodbye!")
                                sys.exit()
                    Claim_Amount=float(choice_3)
                    row["Claim Amount"]=Claim_Amount 
                        
                        
                    choice_4=input("Enter outstanding loan amount, or input 'Quit' to exit: ")              # choice_4 = outstanding loan amount
                    if choice_4.lower()=="quit":
                        print("Have a nice day! Goodbye!")
                        sys.exit()
                    while choice_4.isnumeric()==False:
                        choice_4=input("Invalid amount! Enter outstanding loan amount, or input 'Quit' to exit: ")
                        if choice_4.lower()=="quit":
                            print("Have a nice day! Goodbye!")
                            sys.exit()
                    while float(choice_4)+float(choice_3)>float(choice_2):
                        choice_4=input("Final Claim Amount cannot be negative! Enter outstanding loan amount, or input 'Quit' to exit: ")
                        if choice_4.lower()=="quit":
                            print("Have a nice day! Goodbye!")
                            sys.exit()
                        while choice_4.isnumeric()==False:
                            choice_4=input("Invalid amount! Enter outstanding loan amount, or input 'Quit' to exit: ")
                            if choice_4.lower()=="quit":
                                print("Have a nice day! Goodbye!")
                                sys.exit() 
                    outstanding_payment=float(choice_4)       
                    row["Outstanding loan / payments"]=outstanding_payment
                    
                    final_amount=float(Claim_Amount)-float(outstanding_payment) #final claim amount cannot be more than claim amount itself
                    row["Final Claim Amount"]=str(final_amount)
                    row["Status"]="Pending"
                    row["Comments"]=claim_manager_comments() #maybe need to include new column that has final insured amount left to allow for new claims of the same policy
                    if row["Comments"] == 1:
                        row["Status"]="Completed"
                        row["Comments"]="Failed to Claim: Claim fully redeemed."
                    elif row["Comments"]==6:
                        row["Status"]="Completed"
                        row["Comments"]="Your claim has been disbursed and is completed"   
                    return row 
                else:
                    print("No new claim! Unable to manage.")
                    sys.exit()


def write_newfile(): #download to new file
    f=open("new claim.csv","w", newline="")
    with f:
        fnames=['IC','Name','Gender','DOB','Policy Number','Policy Type','Car Plate number','Agent Code','Insured Amount','Outstanding loan / payments','Claim Amount','Final Claim Amount','Status','Comments']
        writer=csv.DictWriter(f, fieldnames=fnames)
        writer.writeheader()
        writer.writerow(c_final_amount())
        print("File saved in file name:new claim.csv")


def write_existingfile():
    f=open("new claim.csv","w", newline="")
    with f:
        fnames=['IC','Name','Gender','DOB','Policy Number','Policy Type','Car Plate number','Agent Code','Insured Amount','Outstanding loan / payments','Claim Amount','Final Claim Amount','Status','Comments']
        writer=csv.DictWriter(f, fieldnames=fnames)
        writer.writeheader()
        writer.writerow(comments_update())
        print("File saved in file name:new claim.csv")
        



def claim_manager_comments(): 
    print("""\nPick a number to choose which comment you would like to input: 
1) Claim amount is fully redeemed.  
2) Please check your details.
3) I have edited your details. Please check again
4) You are missing certain documents. Please provide them accordingly.
5) All details and documents are correct! Your claim should be coming soon!
6) Your claim has been disbursed and is compeleted.
7) Quit""")
    comments_option=int(input("Which comment would you like to input? "))
    if comments_option == 1: 
        print("Failed to Claim: Claim fully redeemed.")
        return comments_option
    elif comments_option == 2:
        return "Please check your details."
    elif comments_option == 3:
        return "I have edited your details. Please check again." # claim mgr has to edit amounts
    elif comments_option == 4: 
        return "You are missing certain documents. Please provide them accordingly."
    elif comments_option == 5:    
        return "All details and documents are correct! Your claim should be coming soon!"
    elif comments_option == 6:
        print("Your claim has been disbursed and is completed")
        return comments_option
    elif comments_option == 7:
        print("Have a nice day! Thank you!")
        sys.exit()
    
def comments_update():    
    pending_list=[]
    f=open("CM master.csv", "r+") 
    with f: 
        reader=csv.DictReader(f)
        for row2 in reader:
            if row2["Status"]=="Pending":
                pending_list.append(row2["Policy Number"])
        pendingpolicy=input("Enter policy number which you would like to manage, or input 'Quit' to exit.: ")
        if pendingpolicy.lower()=='quit':
            print("Have a nice day! Goodbye!")
            sys.exit()
        while pendingpolicy not in pending_list:                     #need to include something so that we cannot enter other policy numbers that are not 'pending'
            pendingpolicy=input("Invalid policy number! Enter policy number which you would like to manage, or input 'Quit' to exit.: ")  
            if pendingpolicy.lower()=='quit':
                print("Have a nice day! Goodbye!")
                sys.exit()
                
        
    ff=open("CM master.csv", "r+") 
    with ff:
        reader=csv.DictReader(ff)
        for row in reader:
            if row["Policy Number"] == pendingpolicy:
                row["Comments"]=claim_manager_comments() 
                if row["Comments"] == 1:
                    row["Status"]="Completed"
                    row["Comments"]="Failed to Claim: Claim fully redeemed."
                elif row["Comments"]==6:
                    row["Status"]="Completed"
                    row["Comments"]="Your claim has been disbursed and is completed"   
                return row      
    
def claimant_comments(): 
    print("""\nPick a number to choose which comment you would like to input: 
1) Claim Manager has made a mistake in my claim details!.  
2) I have submitted my necessary documents.  
3) All details are correct!
4) Quit""")
    comments_option=int(input("Which comment would you like to input? "))
    if comments_option == 1: 
        return "You made a mistake in my claim details!" 
    elif comments_option == 2: 
        return "I have submitted my necessary documents." 
    elif comments_option == 3: 
        return "All details are correct!" 
    elif comments_option==4:
        print("Have a nice day! Thank you!")
        sys.exit()    

menu() #start from here 
fnames=['IC','Name','Gender','DOB','Policy Number','Policy Type','Car Plate number','Agent Code','Insured Amount','Outstanding loan / payments','Claim Amount','Final Claim Amount','Status','Comments']
option = input("Please enter your option: ")
while option!="1" and option!="2" and option!="3":
    option=input("No such option! Try again. Please enter your option: ")

if option == "1":
    print("Please use one of the default profiles: S9494700F, S9148697J, S9479695D, S9865747I, S9052287F")
    f=open("CM master.csv", "r") 
    with f: 
        reader=csv.DictReader(f) 
        nric = input("Please enter your NRIC to log in, or input 'Quit' to exit: ")
        if nric.lower()=='quit':
            print("Have a nice day! Goodbye!")
            sys.exit()
        while not nric in ic_list:
            nric=input("Invalid NRIC! Enter NRIC to log in, or input 'Quit' to exit: ")
            if nric.lower()=='quit':
                print("Have a nice day! Goodbye!")
                sys.exit()
        print("These are your active policies: ")
        for row in reader:
            if row["IC"] == nric:
                print(row["Policy Number"], row["Policy Type"])
    
    f2=open("CM master.csv", "r") 
    with f2:
        reader2=csv.DictReader(f2)
        policy = input("Enter the policy number of the policy you wish to view, or input 'Quit' to exit: ")
        if policy.lower()=="quit":
            print("Have a nice day! Goodbye!")
            sys.exit()
        while not policy in policy_list:
            policy = input("Invalid policy! Enter policy number you wish to view, or input 'Quit' to exit: ")
            if policy.lower()=="quit":
                print("Have a nice day! Goodbye!")
                sys.exit()
        for row2 in reader2:    
            if row2['Policy Number'] == policy:
                print("These are your details: ")
                for head in fnames:
                    print(f"{head}: {row2[head]}")
                    
                if row2["Status"]=="":
                    user_decision=input("Would you like to claim this policy (Y/N)?: ").upper()
                    while user_decision != "Y" and user_decision!="N":
                        user_decision=input("Wrong input, try again! Would you like to claim this policy? (Y/N): ").upper()
                    if user_decision == "Y":
                        data_dic[policy][12] = "New Claim"
                        with open("CM Master.csv","w+",newline="") as fw:
                            fwrite=csv.writer(fw)
                            fwrite.writerow(fnames)
                            for keys in data_dic:
                                updatedrows=data_dic[keys]
                                fwrite.writerow(updatedrows)
                        print("Your claim has been submitted. Please check back for updates, thank you!")
                    elif user_decision == "N":
                        print("Alright thank you! We hope to see you again.")
                        sys.exit()
                
                elif row2["Status"]=="Pending":
                    user_decision2=input("Would you like to add comment (Y/N)? ").upper()
                    while user_decision2 != "Y" and user_decision2 !="N":
                        user_decision2=input("Wrong input, try again! Would you like to claim this policy? (Y/N): ").upper()
                    if user_decision2 == "Y":
                        user_comment = claimant_comments()
                        data_dic[policy][13] = user_comment
                        
                        with open("new claim.csv", "w+",newline="") as fff: 
                            fwrite=csv.writer(fff)
                            fwrite.writerow(fnames)
                            fwrite.writerow(data_dic[policy])
                        
                        with open("CM Master.csv","w+",newline="") as fw:
                            fwrite=csv.writer(fw)
                            fwrite.writerow(fnames)
                            for keys in data_dic:
                                updatedrows=data_dic[keys]
                                fwrite.writerow(updatedrows)
                        print("Thank you! Have a nice day!")
                    elif user_decision2 == "N":
                        print("Thank you! Have a nice day!")
                        sys.exit()
                        
                elif row2["Status"] == "Completed": #allow for new claims still
                    print("""Apologies for the inconvenience. You have claimed this policy previously.
Please contact your agent for assistance. Thank you.""") #if want to claim the same policy again, then there's no option for that
                        
    
#chong's part
    
if option == "2":
    f=open("CM master.csv", "r") 
    with f: 
        reader=csv.DictReader(f)
        print("Please use the default Agent Code 4007")
        user = input("Please enter your agent code, or input 'Quit' to exit: ")
        if user.lower()=='quit':
            print("Thank you! Have a nice day!")
            sys.exit()
        while not user in agent_list:
            user=input("Invalid agent code! Enter your agent code, or input 'Quit' to exit: ")
            if user.lower()=='quit':
                print("Thank you! Have a nice day!")
                sys.exit()
        pw = input("Please enter your password: ") #set your own password, thus can be anything. can be abit more creative and set some requirements
        a="\t"
        print(f"""\n{a*6}Hello Agent {user}!
{a*5}This is your dashboard
{a*4}Below are your outstanding policies: \n""")
        newcount=0
        pendingcount=0
        new_claim="" #giving dummy value
        for row in reader:
            if row['Agent Code']==user:
                print(f"These are {row['Name']}'s details:")
                for head in fnames:
                    print(f"{head}: {row[head]}")
                if row['Status']=='New Claim':
                    newcount+=1
                    new_claim=row["Status"]
                if row['Status'] == "Pending":
                    pendingcount+=1
                    pending_claim=row["Status"]
                print("")
        print(f"You have {newcount} new claim(s) outstanding.\nYou have {pendingcount} pending claim(s) outstanding.")
        option2 = ""
        print("What would you like to do today?")
        print("1) Manage new claim \n2) Manage pending claims \n3) Quit")
        option2=int(input("Please select your option: "))
        
        if option2 == 1 and new_claim=="New Claim":     
            print("These are your new claims:")
            for values in data_dic.values():
                if values[12]=="New Claim":
                    print(f"{values[1]}: {values[4]} {values[5]}")
            write_newfile()
         
            with open("new claim.csv", "r") as fff:
                fupdate=csv.reader(fff)
                next(fupdate)
                updates=next(fupdate) #but this only assume got one line of updates
                policy_update = updates[4]
                
            for key in data_dic:
                if policy_update == key:
                    data_dic[key] = updates
            
            with open("CM Master.csv","w+",newline="") as fw:
                fwrite=csv.writer(fw)
                fwrite.writerow(fnames)
                for keys in data_dic:
                    updatedrows=data_dic[keys]
                    fwrite.writerow(updatedrows)
                    
        elif option2 == 2 and pending_claim == "Pending":
            print("These are your pending claims:")
            for values in data_dic.values():
                if values[12]=="Pending":
                    print(f"{values[1]}: {values[4]} {values[5]}")
             
            write_existingfile()
            
            with open("new claim.csv", "r") as fff: 
                fupdate=csv.reader(fff)
                next(fupdate)
                updates=next(fupdate) #but this only assume got one line of updates
                policy_update = updates[4]
                
            for key in data_dic:
                if policy_update == key:
                    data_dic[key] = updates
            
            with open("CM Master.csv","w+",newline="") as fw:
                fwrite=csv.writer(fw)
                fwrite.writerow(fnames)
                for keys in data_dic:
                    updatedrows=data_dic[keys]
                    fwrite.writerow(updatedrows)
        
    
        
        else:
            print("Have a nice day! Goodbye!")

if option=="3":
    print("Thank you! Have a nice day.")
    sys.exit()